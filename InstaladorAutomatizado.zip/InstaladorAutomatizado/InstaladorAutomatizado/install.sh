#!/bin/bash
# InstallApps - instala todos os .pkg da pasta AppPadrao com cronômetro em segundos
set -euo pipefail
shopt -s nullglob

LOG="$HOME/Desktop/InstallApps.log"
APP_DIR="$(cd "$(dirname "$0")" && pwd)/AppPadrao"

echo "===== InstallApps $(date) =====" | tee -a "$LOG"

PKGS=("$APP_DIR"/*.pkg)
TOTAL=${#PKGS[@]}
if [ "$TOTAL" -eq 0 ]; then
  echo "⚠️  Nenhum .pkg encontrado em $APP_DIR" | tee -a "$LOG"
  echo "Coloque seus instaladores .pkg dentro de AppPadrao e rode novamente." | tee -a "$LOG"
  exit 0
fi

# ---------- Cronômetro (segundos decorridos) ----------
START_TS=$(date +%s)
ticker() {
  while true; do
    now=$(date +%s)
    elapsed=$((now - START_TS))
    printf "\r⏳ Segundos decorridos: %ds " "$elapsed"
    sleep 1
  done
}
ticker & TICK_PID=$!
stop_ticker() { kill "$TICK_PID" 2>/dev/null || true; echo; }
trap stop_ticker EXIT
# ------------------------------------------------------

done_count=0
for PKG in "${PKGS[@]}"; do
  NAME="$(basename "$PKG")"
  echo; echo "Instalando $NAME... ($((done_count+1))/$TOTAL)" | tee -a "$LOG"

  # Evita bloqueio do Gatekeeper
  xattr -dr com.apple.quarantine "$PKG" 2>/dev/null || true

  # Instala
  /usr/sbin/installer -pkg "$PKG" -target / | tee -a "$LOG"
  echo "------------------------------------" | tee -a "$LOG"
  done_count=$((done_count+1))
done

END_TS=$(date +%s)
total_s=$((END_TS - START_TS))
echo "✅ Finalizado — tempo total: ${total_s}s" | tee -a "$LOG"
